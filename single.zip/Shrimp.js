//Shrimp.js
$(document).ready(function(){
	hh=$(window).height();
	//console.log(hh);
		$(".section .center > div").css("height",hh);
		$(window).on("load resize",function(){
			hh=$(window).height();
			$(".section .center > div").css("height",hh);

		var docpos=new Array(0,0,hh,hh*2,hh*3,hh*4);
		$(".header .center .nav li a").on("click",function(e){
			idx=$(".header .center .nav li a").index($(this));
			//console.log(idx);
			$(this).parent().addClass("active").siblings().removeClass("active");
			$("html, body").animate({scrollTop:docpos[idx]});
			e.preventDefault();
		});
		$(".pagenation li").on("click",function(e){
			idx=$(".pagenation li").index($(this));
			$(this).addClass("active1").siblings().removeClass("active1");
			$("html, body").animate({scrollTop:docpos[idx]});
			e.preventDefault();
		});
		$(".sidenav .m1").on("click",function(e){
			idx=$(".sidenav .m1").index($(this));
			$(this).addClass("active1").siblings().removeClass("active1");
			$("html, body").animate({scrollTop:docpos[idx]});
			e.preventDefault();
		});

		$(".section .center .eat .e_box").css({"top":"900px"});
		$(".container").css({"left":"-1200px"});
		$(".section .center .grow .g_box").css({"top":"-1200px"});

		$(".nav li a").eq(0).on("click",function(){
			$(".nav li a").eq(1).trigger("click");
		});
		$(window).scroll(function(){
			if ($(this).scrollTop()>=hh*4)
			{
				$(".nav li ").eq(5).addClass("active").siblings().removeClass("active");
				$(".pagenation li ").eq(5).addClass("active1").siblings().removeClass("active1");
				$(".section .center .grow .g_box:nth-child(2)").animate({"top":"0px"},1000);
				$(".section .center .grow .g_box:nth-child(3)").animate({"top":"0px"},1300);
				$(".section .center .grow .g_box:nth-child(4)").animate({"top":"0px"},1500);
				$(".section .center .grow .g_box:nth-child(5)").animate({"top":"0px"},1700);
			} else if ($(this).scrollTop()>=hh*3 && $(this).scrollTop()<hh*4)
			{
				$(".nav li ").eq(4).addClass("active").siblings().removeClass("active");
				$(".pagenation li ").eq(4).addClass("active1").siblings().removeClass("active1");
				$(".container").animate({"left":"0px"});
			} else if ($(this).scrollTop()>=hh*2 && $(this).scrollTop()<hh*3)
			{
				$(".nav li ").eq(3).addClass("active").siblings().removeClass("active");
				$(".pagenation li ").eq(3).addClass("active1").siblings().removeClass("active1");
				$(".section .center .eat .e_box:nth-child(2)").animate({"top":"0px"},1000);
				$(".section .center .eat .e_box:nth-child(3)").animate({"top":"0px"},1300);
				$(".section .center .eat .e_box:nth-child(4)").animate({"top":"0px"},1600);

			} else  if ($(this).scrollTop()>=hh*1 && $(this).scrollTop()<hh*2)
			{	
				$(".nav li ").eq(2).addClass("active").siblings().removeClass("active");
				$(".pagenation li ").eq(2).addClass("active1").siblings().removeClass("active1");
				
			}	 else {
				$(".nav li ").eq(1).addClass("active").siblings().removeClass("active");
				$(".pagenation li ").eq(1).addClass("active1").siblings().removeClass("active1");
			}
		});//window scroll		
	});//resize
});//doc
var slideIndex = 1;
		showSlides(slideIndex);

		function plusSlides(n) {
		  showSlides(slideIndex += n);
		}

		function currentSlide(n) {
		  showSlides(slideIndex = n);
		}

		function showSlides(n) {
		  var i;
		  var slides = document.getElementsByClassName("mySlides");
		  if (n > slides.length) {slideIndex = 1}    
		  if (n < 1) {slideIndex = slides.length}
		  for (i = 0; i < slides.length; i++) {
			  slides[i].style.display = "none";  
		  }
		  slides[slideIndex-1].style.display = "block";  
		}
function openNav() {
    document.getElementById("mySidenav").style.display = "block";
}

function closeNav() {
    document.getElementById("mySidenav").style.display = "none";
}
